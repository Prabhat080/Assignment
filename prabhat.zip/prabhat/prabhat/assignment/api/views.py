from django.shortcuts import render
from datetime import datetime
import pandas as pd 
import numpy as np
from rest_framework.views import APIView
from rest_framework.response import Response
# Create your views here.
def convert(x):
    x = datetime.strptime(x, "%Y-%m-%d %H:%M:%S %z")
    return x.date()

path = 'api\data.csv'

class Api1(APIView):

    def get(self,request,format = None):

        df = pd.read_csv(path)
        df['date'] = df['date'].apply(convert)
        start_date = request.GET.get('start_date')
        start_date = datetime.strptime(start_date, "%Y-%m-%d").date()
        end_date = request.GET.get('end_date')
        end_date = datetime.strptime(end_date, "%Y-%m-%d").date()
        department = request.GET.get("department")
        a = df[(df['department']==department) & (df['date']<=end_date) & (df['date']>=start_date)]['seats'].sum()
        return Response({"total_items":a})

class Api2(APIView):
    pass


class Api3(APIView):
    def get(self,request, format=None):
        df = pd.read_csv(path)
        df['date'] = df['date'].apply(convert)
        start_date = request.GET.get('start_date')
        start_date = datetime.strptime(start_date, "%Y-%m-%d").date()
        end_date = request.GET.get('end_date')
        end_date = datetime.strptime(end_date, "%Y-%m-%d").date()
        total_item  = df[(df['date']<=end_date) & (df['date']>=start_date)]['seats'].sum()
        temp =        df[(df['date']<=end_date) & (df['date']>=start_date)].groupby('department')
        l1 = []
        for i in (temp['seats'].sum()):
            l1.append(i)

        dept = []
        for i in sorted(df['department'].unique()):
            dept.append(i)
        dict_ = {}

        for i in range(len(dept)):
            if dict_.get(dept[i]) is None:
                dict_[dept[i]] = 0
            dict_[dept[i]] = (l1[i]/total_item) *100

        return Response(dict_)


class Api4(APIView):
    pass