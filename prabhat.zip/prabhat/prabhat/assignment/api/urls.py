from django.urls import path,include
from .views import Api1,Api2,Api3,Api4
urlpatterns = [
    path('total_items',Api1.as_view()),
    path('/nth_most_total_item',Api2.as_view()),
    path('percentage_of_department_wise_sold_items',Api3.as_view()),
    path('monthly_sales',Api4.as_view())
]
