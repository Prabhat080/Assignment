---install Numpy and Pandas using:
    pip install numpy
    pip install pandas

put data.csv file into the assignment/api folder
